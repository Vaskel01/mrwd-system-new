import { useState, useEffect, useRef } from 'react'
import { useForm, useWatch } from 'react-hook-form'
import { z } from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { useAuthStore } from '../../store/authStore'
import { useComplaintStore } from '../../store/complaintStore'
import { COMPLAINT_TYPES } from '../../config/staticData'
import { ErrorBanner } from '../../components/ui/Feedback'
import AppIcon from '../../components/ui/AppIcon'
import { MAP_PIN_DARK_COLOR } from '../../config/uiTokens'
import { TERMS } from '../../config/terminology'
import { apiFetch } from '../../lib/api'
import {
  COMPLAINT_ADDRESS_MIN_LENGTH,
  COMPLAINT_DESCRIPTION_MAX_LENGTH,
  COMPLAINT_DESCRIPTION_MIN_LENGTH,
  COMPLAINT_VALIDATION_MESSAGES,
} from '../../config/complaintValidation'

const schema = z.object({
  complaint_type: z.string().min(1, COMPLAINT_VALIDATION_MESSAGES.complaint_type),
  description: z.string()
    .trim()
    .min(COMPLAINT_DESCRIPTION_MIN_LENGTH, COMPLAINT_VALIDATION_MESSAGES.description_too_short)
    .max(COMPLAINT_DESCRIPTION_MAX_LENGTH, COMPLAINT_VALIDATION_MESSAGES.description_too_long),
  address: z.string().trim().min(COMPLAINT_ADDRESS_MIN_LENGTH, COMPLAINT_VALIDATION_MESSAGES.address),
})

const STEP_LABELS = ['Type', 'Problem', 'Location', 'Review']
const DRAFT_KEY = 'mrwd:complaint-draft:v1'

function readComplaintDraft() {
  if (typeof window === 'undefined') return null
  try {
    const raw = window.localStorage.getItem(DRAFT_KEY)
    if (!raw) return null
    const draft = JSON.parse(raw)
    return draft && typeof draft === 'object' ? draft : null
  } catch {
    window.localStorage.removeItem(DRAFT_KEY)
    return null
  }
}

function draftStep(draft) {
  if (!Number.isInteger(draft?.step)) return 0
  return Math.min(Math.max(draft.step, 0), 3)
}

const TYPE_ICONS = {
  'No Water': 'waterOff',
  'Water Leak': 'droplet',
  'Low Water Pressure': 'pressure',
  'Dirty / Discolored Water': 'alert',
  'Billing Concern': 'billing',
  'Meter Problem': 'meter',
  'New Connection Request': 'tool',
  'Other': 'document',
}

// ── Interactive pin-on-map using Leaflet (loaded via CDN) ───────────────────
function PinMap({ lat, lng, onPinChange }) {
  const mapRef = useRef(null)
  const leafletMap = useRef(null)
  const markerRef = useRef(null)
  const initialPositionRef = useRef({ lat, lng })
  const onPinChangeRef = useRef(onPinChange)

  useEffect(() => {
    onPinChangeRef.current = onPinChange
  }, [onPinChange])

  useEffect(() => {
    // Load Leaflet CSS
    if (!document.getElementById('leaflet-css')) {
      const link = document.createElement('link')
      link.id = 'leaflet-css'
      link.rel = 'stylesheet'
      link.href = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css'
      document.head.appendChild(link)
    }

    // Load Leaflet JS then init map
    const initMap = () => {
      if (leafletMap.current || !mapRef.current) return
      const L = window.L
      const initialPosition = initialPositionRef.current
      const initLat = initialPosition.lat || 11.5869  // Roxas City default
      const initLng = initialPosition.lng || 122.7511

      const map = L.map(mapRef.current, { zoomControl: true, scrollWheelZoom: false }).setView([initLat, initLng], initialPosition.lat ? 16 : 12)
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors', maxZoom: 19,
      }).addTo(map)

      // Custom marker icon
      const icon = L.divIcon({
        html: `<div style="width:28px;height:28px;background:${MAP_PIN_DARK_COLOR};border:3px solid white;border-radius:50% 50% 50% 0;transform:rotate(-45deg);box-shadow:0 2px 6px rgba(0,0,0,.35)"></div>`,
        iconSize: [28, 28], iconAnchor: [14, 28], className: '',
      })

      if (initialPosition.lat && initialPosition.lng) {
        const m = L.marker([initialPosition.lat, initialPosition.lng], { draggable: true, icon }).addTo(map)
        m.on('dragend', () => {
          const { lat: la, lng: lo } = m.getLatLng()
          reverseGeocode(la, lo, onPinChangeRef.current)
        })
        markerRef.current = m
      }

      map.on('click', (e) => {
        const { lat: la, lng: lo } = e.latlng
        if (markerRef.current) {
          markerRef.current.setLatLng([la, lo])
        } else {
          const m = L.marker([la, lo], { draggable: true, icon }).addTo(map)
          m.on('dragend', () => {
            const { lat: la2, lng: lo2 } = m.getLatLng()
            reverseGeocode(la2, lo2, onPinChangeRef.current)
          })
          markerRef.current = m
        }
        reverseGeocode(la, lo, onPinChangeRef.current)
      })

      leafletMap.current = map
    }

    if (window.L) {
      initMap()
    } else {
      const script = document.createElement('script')
      script.src = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js'
      script.onload = initMap
      document.head.appendChild(script)
    }

    return () => {
      if (leafletMap.current) { leafletMap.current.remove(); leafletMap.current = null; markerRef.current = null }
    }
  }, [])

  return (
    <div>
      <div ref={mapRef} style={{ height: 240, width: '100%' }} className="border border-gray-200" />
      <p className="text-xs text-gray-500 mt-1.5">Tap the map or drag the pin to set the exact location.</p>
    </div>
  )
}

async function reverseGeocode(lat, lng, callback) {
  try {
    const r = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json`)
    const d = await r.json()
    callback({ lat, lng, accuracy: 10, address: d?.display_name || `${lat.toFixed(6)}, ${lng.toFixed(6)}` })
  } catch {
    callback({ lat, lng, accuracy: 10, address: `${lat.toFixed(6)}, ${lng.toFixed(6)}` })
  }
}

export default function SubmitComplaintPage() {
  const user            = useAuthStore(s => s.user)
  const submitComplaint = useComplaintStore(s => s.submitComplaint)
  const [serviceAccounts, setServiceAccounts] = useState([])
  const [serviceAccountId, setServiceAccountId] = useState('')
  const [accountError, setAccountError] = useState('')
  useEffect(() => {
    apiFetch('/service-accounts').then(data => setServiceAccounts(data.accounts)).catch(err => setAccountError(err.message))
  }, [])

  const [initialDraft] = useState(() => readComplaintDraft())
  const initialStep = draftStep(initialDraft)
  const [step, setStep] = useState(initialStep)
  const [furthestStep, setFurthestStep] = useState(initialStep)
  const [photo, setPhoto] = useState(null)
  const [photoPreview, setPhotoPreview] = useState(null)
  const [submitting, setSubmitting] = useState(false)
  const [submitError, setSubmitError] = useState(null)
  const [submitted, setSubmitted] = useState(null)
  const [draftRestored, setDraftRestored] = useState(() => Boolean(
    initialDraft?.complaint_type || initialDraft?.description || initialDraft?.address,
  ))
  const [draftSavedAt, setDraftSavedAt] = useState(null)

  // GPS / location state
  const [locationMode, setLocationMode] = useState(() => initialDraft?.locationMode || null) // null | 'saved' | 'gps' | 'pin'
  const [gpsCoords, setGpsCoords] = useState(() => initialDraft?.gps || null)       // { lat, lng, accuracy }
  const [gpsLoading, setGpsLoading] = useState(false)
  const [gpsError, setGpsError] = useState(null)

  const { register, handleSubmit, control, reset, trigger, setValue, setError, setFocus, formState: { errors } } = useForm({
    resolver: zodResolver(schema),
    defaultValues: {
      complaint_type: initialDraft?.complaint_type || '',
      description: initialDraft?.description || '',
      address: initialDraft?.address || '',
    },
  })

  const watchedType = useWatch({ control, name: 'complaint_type', defaultValue: '' })
  const watchedDesc = useWatch({ control, name: 'description', defaultValue: '' })
  const watchedAddr = useWatch({ control, name: 'address', defaultValue: '' })

  useEffect(() => {
    const hasDraft = Boolean(watchedType || watchedDesc?.trim() || watchedAddr?.trim())
    if (!hasDraft || submitted) return undefined
    const timer = window.setTimeout(() => {
      window.localStorage.setItem(DRAFT_KEY, JSON.stringify({
        complaint_type: watchedType,
        description: watchedDesc,
        address: watchedAddr,
        gps: gpsCoords,
        locationMode,
        step,
      }))
      setDraftSavedAt(new Date())
    }, 350)
    return () => window.clearTimeout(timer)
  }, [watchedType, watchedDesc, watchedAddr, gpsCoords, locationMode, step, submitted])

  useEffect(() => {
    const onBeforeUnload = event => {
      if (!(watchedType || watchedDesc?.trim() || watchedAddr?.trim()) || submitting || submitted) return
      event.preventDefault()
      event.returnValue = ''
    }
    window.addEventListener('beforeunload', onBeforeUnload)
    return () => window.removeEventListener('beforeunload', onBeforeUnload)
  }, [watchedType, watchedDesc, watchedAddr, submitting, submitted])

  const handlePhotoChange = (e) => {
    const file = e.target.files[0]
    if (!file) return
    setPhoto(file)
    setPhotoPreview(URL.createObjectURL(file))
  }

  const removePhoto = () => { setPhoto(null); setPhotoPreview(null) }

  // ── GPS / Geolocation ────────────────────────────────────────────────────
  const requestGPS = () => {
    if (!navigator.geolocation) {
      setGpsError('Geolocation is not supported by your browser.')
      return
    }
    setLocationMode('gps')
    setGpsCoords(null)
    setValue('address', '', { shouldValidate: false })
    setGpsLoading(true)
    setGpsError(null)
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude: lat, longitude: lng, accuracy } = pos.coords
        setGpsCoords({ lat, lng, accuracy: Math.round(accuracy) })
        setGpsLoading(false)
        setLocationMode('gps')
        // Reverse-geocode using Nominatim (no API key needed)
        fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json`)
          .then(r => r.json())
          .then(data => {
            if (data && data.display_name) {
              setValue('address', data.display_name, { shouldValidate: true })
            }
          })
          .catch(() => {
            setValue('address', `${lat.toFixed(6)}, ${lng.toFixed(6)}`, { shouldValidate: true })
          })
      },
      (err) => {
        setGpsLoading(false)
        if (err.code === 1) setGpsError('Location access denied. Please allow location permission and try again.')
        else if (err.code === 2) setGpsError('Location unavailable. Please enter address manually.')
        else setGpsError('Location request timed out. Please enter address manually.')
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    )
  }

  const clearGPS = () => {
    setGpsCoords(null)
    setGpsError(null)
    setLocationMode(null)
    setValue('address', user?.service_address || '', { shouldValidate: false })
  }
  // ────────────────────────────────────────────────────────────────────────

  const goNext = async () => {
    let valid = true
    if (step === 0) valid = await trigger('complaint_type', { shouldFocus: true })
    if (step === 1) valid = await trigger('description', { shouldFocus: true })
    if (step === 2) valid = await trigger('address', { shouldFocus: true })
    if (valid) {
      setSubmitError(null)
      setStep(current => {
        const next = current + 1
        setFurthestStep(value => Math.max(value, next))
        return next
      })
    }
  }

  const showValidationErrors = fieldErrors => {
    const stepByField = { complaint_type: 0, description: 1, address: 2 }
    const firstField = ['complaint_type', 'description', 'address'].find(field => fieldErrors?.[field])
    if (!firstField) return false

    for (const [field, value] of Object.entries(fieldErrors)) {
      if (!(field in stepByField)) continue
      const message = typeof value === 'string' ? value : value?.message
      if (message) setError(field, { type: 'server', message })
    }
    const targetStep = stepByField[firstField]
    setStep(targetStep)
    setFurthestStep(value => Math.max(value, targetStep))
    setSubmitError('Please review the highlighted field. Your complaint information is still saved in this browser.')
    window.requestAnimationFrame(() => setFocus(firstField))
    return true
  }

  const onInvalid = fieldErrors => showValidationErrors(fieldErrors)

  const onSubmit = async (data) => {
    setSubmitting(true)
    setSubmitError(null)
    try {
      const result = await submitComplaint(
        { ...data, photo, gps: gpsCoords, service_account_id: serviceAccountId },
        user.id,
        user.full_name
      )
      setSubmitted(result)
      window.localStorage.removeItem(DRAFT_KEY)
      setDraftSavedAt(null)
      setDraftRestored(false)
      reset()
      setPhoto(null); setPhotoPreview(null); setStep(0); setFurthestStep(0)
      setGpsCoords(null); setGpsError(null); setLocationMode(null)
    } catch (err) {
      if (!showValidationErrors(err.fieldErrors)) {
        setSubmitError(err.message || "We couldn't submit your complaint. Your information is still saved in this browser; please try again.")
      }
    } finally { setSubmitting(false) }
  }

  if (submitted) {
    return (
      <div className="max-w-lg mx-auto py-8 px-4">
        <div className="card rounded-xl overflow-hidden">
          <div className="h-2 w-full bg-gold-400" />
          <div className="p-8 text-center">
            <div className="w-14 h-14 rounded-2xl bg-navy-800 flex items-center justify-center mx-auto mb-4">
              <svg className="w-7 h-7 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                <path strokeLinecap="square" strokeLinejoin="miter" d="M5 13l4 4L19 7"/>
              </svg>
            </div>
            <h2 className="text-xl font-black text-gray-900 mb-1 font-display tracking-tight">Complaint submitted</h2>
            <p className="text-gray-500 text-sm mb-6">Your complaint is now waiting for Commercial Services review.</p>

            <div className="text-left rounded-lg border border-gray-100 divide-y divide-gray-100 mb-6 text-sm">
              <div className="flex items-center justify-between px-4 py-3">
                <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">{TERMS.REFERENCE_NUMBER}</span>
                <span className="font-mono text-xs font-bold text-gray-700">{submitted.reference_number}</span>
              </div>
              <div className="flex items-center justify-between px-4 py-3">
                <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">Complaint Type</span>
                <span className="font-semibold text-gray-800 text-right">{submitted.complaint_type}</span>
              </div>
              {submitted.gps && (
                <div className="flex items-center justify-between px-4 py-3">
                  <span className="text-xs font-bold text-gray-500 uppercase tracking-wider">GPS</span>
                  <span className="font-mono text-xs text-green-700 bg-green-50 px-2 py-0.5">
                    <AppIcon name="location" className="inline-block w-3.5 h-3.5 mr-1" />
                    {submitted.gps.lat.toFixed(5)}, {submitted.gps.lng.toFixed(5)}
                  </span>
                </div>
              )}
            </div>
            <button onClick={() => setSubmitted(null)} className="btn-primary w-full">Submit another complaint</button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="w-full space-y-5">
      {draftRestored && <div className="flex flex-col gap-2 rounded-xl border border-blue-200 bg-blue-50 px-4 py-3 text-sm text-blue-900 sm:flex-row sm:items-center sm:justify-between"><div><b>Draft restored.</b> Your unfinished complaint was recovered from this browser. {draftSavedAt && <span className="text-blue-700"> Changes are saved automatically.</span>}</div><button type="button" onClick={() => { window.localStorage.removeItem(DRAFT_KEY); reset({ complaint_type: '', description: '', address: '' }); setGpsCoords(null); setLocationMode(null); setStep(0); setFurthestStep(0); setDraftRestored(false); setDraftSavedAt(null) }} className="text-xs font-black text-blue-800 underline">Discard draft</button></div>}
      {/* Page header */}
      <div className="page-band wave-header page-header">
        <p className="mb-1.5 text-xs font-bold uppercase tracking-[.15em] text-gold-400">Customer account</p>
        <h1 className="text-white">Submit a complaint</h1>
        <p>Tell us what happened and where. Clear details help MRWD review your complaint faster.</p>
      </div>

      {/* Step rail */}
      <div className="grid grid-cols-4 gap-1.5 sm:gap-2">
        {STEP_LABELS.map((label, i) => {
          const completed = i < furthestStep
          const canJump = completed && i !== step
          return (
          <button type="button" key={i} onClick={() => canJump && setStep(i)} disabled={!canJump}
            aria-current={i === step ? 'step' : undefined}
            className={`min-h-11 min-w-0 flex items-center justify-center sm:justify-start gap-1.5 sm:gap-2 px-2 sm:px-3 rounded-xl text-xs font-bold transition-colors border ${
              i === step ? 'bg-navy-900 text-white border-navy-900' :
              completed ? 'bg-navy-800 text-white border-gold-500 cursor-pointer hover:bg-navy-700' :
                          'bg-white text-gray-500 border-gray-200'
            }`}>
              <span className={`w-5 h-5 flex items-center justify-center text-xs font-black shrink-0 ${
                i < step ? '' : i === step ? '' : 'opacity-50'
              }`}>
                {completed ? <AppIcon name="check" className="w-4 h-4" /> : i + 1}
              </span>
              <span className="hidden sm:inline truncate">{label}</span>
          </button>
        )})}
      </div>

      <section className="card rounded-xl p-5 space-y-2">
        <label className="block text-sm font-bold text-gray-700">Service account (optional)
          <select className="input-field mt-2" value={serviceAccountId} onChange={event => {
            setServiceAccountId(event.target.value)
            const account = serviceAccounts.find(item => item.id === event.target.value)
            if (account?.service_address) { setValue('address', account.service_address); setGpsCoords(null); setLocationMode('saved') }
          }}>
            <option value="">General complaint / account not yet verified</option>
            {serviceAccounts.map(account => <option key={account.id} value={account.id}>{account.account_number} — {account.service_address || account.registered_name}</option>)}
          </select>
        </label>
        <p className="text-xs text-gray-500">Manage verified connections in Billing. You can submit a complaint without an account link.</p>
        {accountError && <p role="alert" className="text-xs text-red-700">Service accounts could not load: {accountError}. You can still file a general complaint.</p>}
      </section>
      <form onSubmit={handleSubmit(onSubmit, onInvalid)}>
        {submitError && <ErrorBanner message={submitError} className="mb-4" />}

        {/* Step 0 — Type */}
        {step === 0 && (
          <div className="card rounded-xl overflow-hidden">
            <div className="px-5 py-3 border-b border-gray-100 bg-gray-50">
              <p className="text-xs font-black text-gray-500 uppercase tracking-widest">Choose the complaint type</p>
            </div>
            <div className="p-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {COMPLAINT_TYPES.map(t => (
                  <label key={t} className={`flex items-center gap-3 p-3 rounded-lg border-2 cursor-pointer transition-all ${
                    watchedType === t ? 'border-gold-500 bg-gold-50' : 'border-gray-100 hover:border-gray-300 bg-white'
                  }`}>
                    <input aria-label="Complaint type" type="radio" value={t} {...register('complaint_type')} className="sr-only" />
                    <AppIcon name={TYPE_ICONS[t] || 'document'} className="w-6 h-6 shrink-0 text-navy-700" />
                    <span className={`text-sm font-semibold ${watchedType === t ? 'text-navy-800' : 'text-gray-700'}`}>{t}</span>
                  </label>
                ))}
              </div>
              {errors.complaint_type && <p className="mt-3 text-xs text-red-600 font-semibold">{errors.complaint_type.message}</p>}
              <button type="button" onClick={goNext} className="btn-primary mt-5 w-full">Continue</button>
            </div>
          </div>
        )}

        {/* Step 1 — Description */}
        {step === 1 && (
          <div className="card rounded-xl overflow-hidden">
            <div className="px-5 py-3 border-b border-gray-100 bg-gray-50 flex items-center justify-between">
              <p className="text-xs font-black text-gray-500 uppercase tracking-widest">Describe the problem</p>
              <span className="text-xs font-mono text-gray-500">{watchedType}</span>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <div className="flex flex-wrap justify-between gap-1 mb-1.5">
                  <label htmlFor="complaint-description" className="text-sm font-bold text-gray-700">Problem details <span className="text-red-500">*</span></label>
                  <span className="text-xs text-gray-500">At least {COMPLAINT_DESCRIPTION_MIN_LENGTH} characters</span>
                </div>
                <textarea
                  id="complaint-description"
                  aria-label="Description"
                  aria-describedby={`complaint-description-help${errors.description ? ' complaint-description-error' : ''}`}
                  aria-invalid={Boolean(errors.description)}
                  rows={5}
                  minLength={COMPLAINT_DESCRIPTION_MIN_LENGTH}
                  maxLength={COMPLAINT_DESCRIPTION_MAX_LENGTH}
                  placeholder="When did it start? How serious is it? Who or what area is affected?"
                  {...register('description')}
                  className={`input-field resize-none ${errors.description ? 'input-error' : ''}`}
                />
                <div className="mt-1.5 flex items-start justify-between gap-3">
                  <span>
                    <span id="complaint-description-help" className="block text-xs text-gray-500">Include when it started, how serious it is, and who or what area is affected.</span>
                    {errors.description && <span id="complaint-description-error" role="alert" className="mt-1 block text-xs font-semibold text-red-600">{errors.description.message}</span>}
                  </span>
                  <span className="shrink-0 text-xs font-bold text-gray-500">{watchedDesc.length.toLocaleString()}/{COMPLAINT_DESCRIPTION_MAX_LENGTH.toLocaleString()}</span>
                </div>
              </div>

              <div>
                <p className="text-sm font-bold text-gray-700 mb-1.5">
                  Photo
                  <span className="ml-2 text-xs font-normal text-gray-500 bg-gray-100 px-2 py-0.5">Optional</span>
                </p>
                {photoPreview ? (
                  <div className="flex items-center gap-3 p-3 border border-gray-200 bg-gray-50">
                    <img src={photoPreview} alt="Preview" className="w-14 h-14 object-cover border border-gray-300"/>
                    <div>
                      <p className="text-xs font-bold text-gray-700">Photo attached</p>
                      <button type="button" onClick={removePhoto} className="text-xs text-red-500 hover:text-red-700 mt-0.5">Remove</button>
                    </div>
                  </div>
                ) : (
                  <label className="flex items-center gap-3 p-4 border-2 border-dashed border-gray-200 cursor-pointer hover:border-gold-400 transition-colors bg-gray-50">
                    <svg className="w-5 h-5 text-gray-500 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                    <span className="text-sm text-gray-500">Add a photo</span>
                    <input name="complaint_photo" aria-label="Complaint photo" type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={handlePhotoChange}/>
                  </label>
                )}
              </div>
            </div>
            <div className="flex gap-0 border-t border-gray-200">
              <button type="button" onClick={() => setStep(0)} className="flex-1 py-3 text-sm font-bold text-gray-600 bg-gray-50 hover:bg-gray-100 border-r border-gray-200 transition-colors">← Back</button>
              <button type="button" onClick={goNext} className="flex-1 py-3 text-sm font-bold text-white bg-navy-800 hover:bg-navy-900 transition-colors">Continue</button>
            </div>
          </div>
        )}

        {/* Step 2 — Location (GPS or pin on map) */}
        {step === 2 && (
          <div className="card rounded-xl overflow-hidden">
            <div className="px-5 py-3 border-b border-gray-100 bg-gray-50">
              <p className="text-xs font-black text-gray-500 uppercase tracking-widest">Set the location</p>
            </div>
            <div className="p-5 space-y-4">

              {/* Location methods remain equally visible; only the chosen method receives emphasis. */}
              <div className={`grid grid-cols-1 gap-3 ${user?.service_address ? 'sm:grid-cols-3' : 'sm:grid-cols-2'}`}>
                  {user?.service_address && (
                    <button
                      type="button"
                      aria-pressed={locationMode === 'saved'}
                      onClick={() => {
                        setValue('address', user.service_address, { shouldValidate: true })
                        setLocationMode('saved')
                        setGpsCoords(null)
                        setGpsError(null)
                      }}
                      className={`flex min-h-24 flex-col items-center justify-center gap-2 rounded-xl border-2 p-4 text-center text-sm font-bold transition-colors ${
                        locationMode === 'saved'
                          ? 'border-navy-700 bg-navy-50 text-navy-900'
                          : 'border-gray-300 bg-white text-gray-600 hover:border-navy-400 hover:text-navy-800'
                      }`}
                    >
                      <AppIcon name="location" className="h-6 w-6 shrink-0" />
                      <span className="text-xs leading-tight">Use saved service address</span>
                      {locationMode === 'saved' && <span className="text-xs font-semibold text-navy-600">Selected</span>}
                    </button>
                  )}
                  {/* GPS button */}
                  <button
                    type="button"
                    aria-pressed={locationMode === 'gps'}
                    onClick={requestGPS}
                    disabled={gpsLoading}
                    className={`flex min-h-24 flex-col items-center justify-center gap-2 rounded-xl border-2 p-4 text-center text-sm font-bold transition-colors disabled:cursor-not-allowed disabled:opacity-60 ${
                      locationMode === 'gps'
                        ? 'border-navy-700 bg-navy-50 text-navy-900'
                        : 'border-gray-300 bg-white text-gray-600 hover:border-navy-400 hover:text-navy-800'
                    }`}
                  >
                    {gpsLoading ? (
                      <div className="h-6 w-6 animate-spin rounded-full border-2 border-navy-700 border-t-transparent" />
                    ) : (
                      <AppIcon name="location" className="h-6 w-6 shrink-0" />
                    )}
                    <span className="text-xs text-center leading-tight">{gpsLoading ? 'Getting location…' : 'Use my location'}</span>
                    {locationMode === 'gps' && !gpsLoading && <span className="text-xs font-semibold text-navy-600">Selected</span>}
                  </button>

                  {/* Pin on map button */}
                  <button
                    type="button"
                    aria-pressed={locationMode === 'pin'}
                    onClick={() => {
                      setLocationMode('pin')
                      setGpsCoords(null)
                      setGpsError(null)
                      setValue('address', '', { shouldValidate: false })
                    }}
                    className={`flex min-h-24 flex-col items-center justify-center gap-2 rounded-xl border-2 p-4 text-center text-sm font-bold transition-colors ${
                      locationMode === 'pin'
                        ? 'border-navy-700 bg-navy-50 text-navy-900'
                        : 'border-gray-300 bg-white text-gray-600 hover:border-navy-400 hover:text-navy-800'
                    }`}
                  >
                    <svg className="w-6 h-6 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"/>
                    </svg>
                    <span className="text-xs text-center leading-tight">Choose on map</span>
                    {locationMode === 'pin' && <span className="text-xs font-semibold text-navy-600">Selected</span>}
                  </button>
              </div>

              {gpsError && (
                <p className="text-xs text-red-600 font-semibold flex items-start gap-1">
                  <AppIcon name="alert" className="w-4 h-4 shrink-0" /> {gpsError}
                </p>
              )}

              {/* GPS success panel */}
              {locationMode === 'gps' && gpsCoords && (
                <div className="border border-green-200 bg-green-50 p-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <AppIcon name="location" className="w-5 h-5 text-green-600" />
                      <div>
                        <p className="text-xs font-black text-green-800 uppercase tracking-wider">Location captured</p>
                        <p className="text-xs text-green-700 font-mono mt-0.5">
                          {gpsCoords.lat.toFixed(6)}, {gpsCoords.lng.toFixed(6)}
                        </p>
                        <p className="text-xs text-green-600 mt-0.5">±{gpsCoords.accuracy}m accuracy</p>
                      </div>
                    </div>
                    <button type="button" onClick={clearGPS} className="text-xs text-red-500 hover:text-red-700 font-bold shrink-0">Change</button>
                  </div>
                </div>
              )}

              {/* Pin on map mode */}
              {locationMode === 'pin' && (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-xs font-black text-gray-500 uppercase tracking-wider">Tap the map or drag the pin</p>
                    <button type="button" onClick={clearGPS} className="text-xs text-gray-500 hover:text-red-500 font-bold">✕ Cancel</button>
                  </div>
                  <PinMap
                    lat={gpsCoords?.lat}
                    lng={gpsCoords?.lng}
                    onPinChange={({ lat, lng, accuracy, address }) => {
                      setGpsCoords({ lat, lng, accuracy })
                      setValue('address', address, { shouldValidate: true })
                    }}
                  />
                  {gpsCoords && (
                    <div className="mt-2 flex items-center gap-1.5 text-xs text-gray-500">
                      <span className="font-mono bg-gray-100 px-2 py-0.5">
                        <AppIcon name="location" className="inline-block w-3.5 h-3.5 mr-1" />
                        {gpsCoords.lat.toFixed(5)}, {gpsCoords.lng.toFixed(5)}
                      </span>
                      <span className="text-gray-500">pinned</span>
                    </div>
                  )}
                </div>
              )}

              {/* Divider + manual entry (always visible after mode shown) */}
              {(locationMode || gpsError) && (
                <div className="flex items-center gap-3">
                  <div className="flex-1 h-px bg-gray-200" />
                  <span className="text-xs text-gray-500 font-bold uppercase tracking-wider">address</span>
                  <div className="flex-1 h-px bg-gray-200" />
                </div>
              )}

              {/* Address text field */}
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1.5">
                  Full Address <span className="text-red-500">*</span>
                  {gpsCoords && <span className="ml-2 text-xs font-normal text-gold-600 bg-gold-50 px-2 py-0.5">Filled from location</span>}
                </label>
                <input aria-label="Address" type="text" placeholder="e.g. 123 Rizal St., Brgy. Baybay, Roxas City, Capiz"
                  {...register('address')}
                  aria-describedby={gpsCoords ? 'address-edit-help' : undefined}
                  className={`input-field ${errors.address ? 'input-error' : ''}`} />
                {gpsCoords && <p id="address-edit-help" className="mt-1.5 text-xs text-gray-500">Location services can be approximate. Check the address and correct anything that looks wrong.</p>}
                {errors.address && <p className="mt-1 text-xs text-red-600">{errors.address.message}</p>}
              </div>
            </div>
            <div className="flex gap-0 border-t border-gray-200">
              <button type="button" onClick={() => setStep(1)} className="flex-1 py-3 text-sm font-bold text-gray-600 bg-gray-50 hover:bg-gray-100 border-r border-gray-200 transition-colors">← Back</button>
              <button type="button" onClick={goNext} className="flex-1 py-3 text-sm font-bold text-white bg-navy-800 hover:bg-navy-900 transition-colors">Review</button>
            </div>
          </div>
        )}

        {/* Step 3 — Review */}
        {step === 3 && (
          <div className="card rounded-xl overflow-hidden">
            <div className="px-5 py-3 border-b border-gray-100 bg-gray-50">
              <p className="text-xs font-black text-gray-500 uppercase tracking-widest">Review your complaint</p>
            </div>
            <div className="divide-y divide-gray-100 text-sm">
              <div className="flex gap-4 px-5 py-3">
                <span className="text-xs font-black text-gray-500 uppercase tracking-wider w-20 shrink-0 pt-0.5">Type</span>
                <span className="font-bold text-gray-900 inline-flex items-center gap-2"><AppIcon name={TYPE_ICONS[watchedType] || 'document'} className="w-5 h-5 text-navy-700" />{watchedType}</span>
              </div>
              <div className="flex gap-4 px-5 py-3">
                <span className="text-xs font-black text-gray-500 uppercase tracking-wider w-20 shrink-0 pt-0.5">Details</span>
                <span className="text-gray-700 leading-relaxed">{watchedDesc}</span>
              </div>
              <div className="flex gap-4 px-5 py-3">
                <span className="text-xs font-black text-gray-500 uppercase tracking-wider w-20 shrink-0 pt-0.5">Location</span>
                <div className="flex-1">
                  <span className="text-gray-700">{watchedAddr}</span>
                  {gpsCoords && (
                    <div className="mt-1.5 flex items-center gap-1.5">
                      <span className="text-xs bg-green-100 text-green-800 font-mono px-2 py-0.5 font-bold">
                        <AppIcon name="location" className="inline-block w-3.5 h-3.5 mr-1" />
                        GPS: {gpsCoords.lat.toFixed(5)}, {gpsCoords.lng.toFixed(5)}
                      </span>
                      <span className="text-xs text-gray-500">±{gpsCoords.accuracy}m</span>
                    </div>
                  )}
                </div>
              </div>
              <div className="flex gap-4 px-5 py-3">
                <span className="text-xs font-black text-gray-500 uppercase tracking-wider w-20 shrink-0 pt-0.5">Photo</span>
                <span className="text-gray-700">{photo ? '✓ Attached' : 'None'}</span>
              </div>
            </div>


            <div className="flex gap-0 border-t border-gray-200">
              <button type="button" onClick={() => setStep(2)} className="flex-1 py-3 text-sm font-bold text-gray-600 bg-gray-50 hover:bg-gray-100 border-r border-gray-200 transition-colors">← Back</button>
              <button type="submit" disabled={submitting} className="flex-1 py-3 text-sm font-bold text-white bg-navy-800 hover:bg-navy-900 disabled:opacity-60 transition-colors flex items-center justify-center gap-2">
                {submitting ? <><div className="w-4 h-4 border-2 border-white border-t-transparent animate-spin"/>Submitting…</> : 'Submit Complaint →'}
              </button>
            </div>
          </div>
        )}
      </form>
    </div>
  )
}
