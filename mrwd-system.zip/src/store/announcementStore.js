import { create } from 'zustand'
import { apiFetch } from '../lib/api'

export const useAnnouncementStore = create((set) => ({
  announcements: [],
  loading: false,
  error: null,

  fetchAnnouncements: async ({ includeExpired = false } = {}) => {
    set({ loading: true, error: null })
    try {
      const { announcements } = await apiFetch(`/announcements${includeExpired ? '?include_expired=true' : ''}`)
      set({ announcements, loading: false })
    } catch (err) {
      set({ loading: false, error: err.message })
    }
  },

  updateAnnouncement: async (id, data) => {
    const { announcement } = await apiFetch(`/announcements/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    })
    set(state => ({
      announcements: state.announcements.map(item => item.id === id ? announcement : item),
    }))
    return announcement
  },

  // Admin: post a new announcement
  postAnnouncement: async (data) => {
    const { announcement } = await apiFetch('/announcements', {
      method: 'POST',
      body: JSON.stringify(data),
    })
    set(s => ({ announcements: [announcement, ...s.announcements] }))
    return announcement
  },

  setAnnouncementImportance: async (id, isImportant) => {
    const { announcement } = await apiFetch(`/announcements/${id}/importance`, {
      method: 'PATCH',
      body: JSON.stringify({ is_important: isImportant }),
    })
    set(s => ({
      announcements: s.announcements.map(item => item.id === id ? announcement : item),
    }))
    return announcement
  },

  // Admin: delete an announcement
  deleteAnnouncement: async (id) => {
    await apiFetch(`/announcements/${id}`, { method: 'DELETE' })
    set(s => ({ announcements: s.announcements.filter(a => a.id !== id) }))
  },
}))
